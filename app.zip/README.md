# reto-tecnico-backend-interseguroGo
Esta API recibirá la matriz original como entrada
